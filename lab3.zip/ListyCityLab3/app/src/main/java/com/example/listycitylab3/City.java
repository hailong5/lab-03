package com.example.listycitylab3;

public class City  {
    private String name;
    private String province;
    int position = -1;

    public City(String name, String province)   {
        this.name = name;
        this.province = province;
    }

    public String getName() {
        return name;
    }

    public String getProvince() {
        return province;
    }

    public int getPosition() {
        return position;
    }
    public void setPosition(int position) {
        this.position = position;
    }
    @Override
    public String toString() {
        return name + ","+ province;
    }
}